import { GameWorld, Player, Camera, Order } from './types';
import { COLORS } from './constants';

// Wind state (shared across frames)
let windAngle = 0.3; // radians, slight angle
let windStrength = 1;
let windPhase = 0;

export function renderGame(
  ctx: CanvasRenderingContext2D,
  canvasW: number,
  canvasH: number,
  world: GameWorld,
  player: Player,
  camera: Camera,
  currentOrder: Order | null,
  time: number,
) {
  // Update wind
  windPhase += 0.01;
  windStrength = 0.8 + 0.4 * Math.sin(windPhase * 0.7);
  windAngle = 0.25 + 0.15 * Math.sin(windPhase * 0.3);

  // Sky
  ctx.fillStyle = COLORS.skyTint;
  ctx.fillRect(0, 0, canvasW, canvasH);

  ctx.save();
  ctx.translate(-camera.x, -camera.y);

  // ═══════════════════════════════
  //  GROUND
  // ═══════════════════════════════
  ctx.fillStyle = COLORS.grass3;
  ctx.fillRect(0, 0, world.width, world.height);

  for (let gx = 0; gx < world.width; gx += 100) {
    for (let gy = 0; gy < world.height; gy += 100) {
      const h = ((gx * 7 + gy * 13) % 60);
      ctx.fillStyle = h < 20 ? COLORS.grass1 : h < 40 ? COLORS.grass2 : COLORS.mud;
      const ox = ((gx * 3 + gy * 7) % 30) - 15;
      ctx.fillRect(gx + ox, gy + ox, 70, 70);
    }
  }

  // ═══════════════════════════════
  //  ROADS
  // ═══════════════════════════════
  for (const road of world.roads) {
    ctx.fillStyle = COLORS.road;
    ctx.fillRect(road.x, road.y, road.width, road.height);

    // Darker edges
    ctx.fillStyle = COLORS.roadDark;
    if (road.direction === 'horizontal') {
      ctx.fillRect(road.x, road.y, road.width, 4);
      ctx.fillRect(road.x, road.y + road.height - 4, road.width, 4);
    } else {
      ctx.fillRect(road.x, road.y, 4, road.height);
      ctx.fillRect(road.x + road.width - 4, road.y, 4, road.height);
    }

    // Center dashed line
    ctx.strokeStyle = COLORS.roadLine;
    ctx.lineWidth = 2;
    ctx.setLineDash([18, 14]);
    if (road.direction === 'horizontal') {
      const midY = road.y + road.height / 2;
      ctx.beginPath();
      ctx.moveTo(road.x, midY);
      ctx.lineTo(road.x + road.width, midY);
      ctx.stroke();
    } else {
      const midX = road.x + road.width / 2;
      ctx.beginPath();
      ctx.moveTo(midX, road.y);
      ctx.lineTo(midX, road.y + road.height);
      ctx.stroke();
    }
    ctx.setLineDash([]);

    // Edge white lines
    ctx.strokeStyle = COLORS.roadLineWhite;
    ctx.lineWidth = 1;
    if (road.direction === 'horizontal') {
      ctx.beginPath();
      ctx.moveTo(road.x, road.y + 2);
      ctx.lineTo(road.x + road.width, road.y + 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(road.x, road.y + road.height - 2);
      ctx.lineTo(road.x + road.width, road.y + road.height - 2);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.moveTo(road.x + 2, road.y);
      ctx.lineTo(road.x + 2, road.y + road.height);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(road.x + road.width - 2, road.y);
      ctx.lineTo(road.x + road.width - 2, road.y + road.height);
      ctx.stroke();
    }
  }

  // ═══════════════════════════════
  //  SIDEWALKS
  // ═══════════════════════════════
  for (const sw of world.sidewalks) {
    ctx.fillStyle = COLORS.sidewalk;
    ctx.fillRect(sw.x, sw.y, sw.width, sw.height);

    ctx.fillStyle = COLORS.curb;
    if (sw.width > sw.height) {
      ctx.fillRect(sw.x, sw.y, sw.width, 2);
      ctx.fillRect(sw.x, sw.y + sw.height - 2, sw.width, 2);
    } else {
      ctx.fillRect(sw.x, sw.y, 2, sw.height);
      ctx.fillRect(sw.x + sw.width - 2, sw.y, 2, sw.height);
    }

    ctx.strokeStyle = COLORS.sidewalkTile;
    ctx.lineWidth = 0.5;
    if (sw.width > sw.height) {
      for (let tx = sw.x; tx < sw.x + sw.width; tx += 28) {
        ctx.beginPath();
        ctx.moveTo(tx, sw.y);
        ctx.lineTo(tx, sw.y + sw.height);
        ctx.stroke();
      }
    } else {
      for (let ty = sw.y; ty < sw.y + sw.height; ty += 28) {
        ctx.beginPath();
        ctx.moveTo(sw.x, ty);
        ctx.lineTo(sw.x + sw.width, ty);
        ctx.stroke();
      }
    }
  }

  // ═══════════════════════════════
  //  PUDDLES (with rain ripples)
  // ═══════════════════════════════
  for (const puddle of world.puddles) {
    ctx.fillStyle = COLORS.puddle;
    ctx.beginPath();
    ctx.ellipse(puddle.x, puddle.y, puddle.radius * 1.4, puddle.radius * 0.9, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = COLORS.puddleRim;
    ctx.lineWidth = 1;
    ctx.stroke();

    // Sky reflection
    ctx.fillStyle = COLORS.puddleShine;
    ctx.globalAlpha = 0.2 + 0.1 * Math.sin(time * 2 + puddle.x * 0.1);
    ctx.beginPath();
    ctx.ellipse(puddle.x - puddle.radius * 0.3, puddle.y - puddle.radius * 0.2,
      puddle.radius * 0.45, puddle.radius * 0.3, -0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;

    // Rain ripples
    for (let r = 0; r < 3; r++) {
      const rippleT = (time * 2.5 + puddle.x * 0.03 + r * 1.3) % 2;
      if (rippleT < 1.2) {
        const rx = puddle.x + Math.sin(puddle.y * 0.5 + r * 2.1) * puddle.radius * 0.4;
        const ry = puddle.y + Math.cos(puddle.x * 0.5 + r * 1.7) * puddle.radius * 0.3;
        ctx.strokeStyle = `rgba(100, 130, 180, ${0.25 * (1 - rippleT / 1.2)})`;
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.arc(rx, ry, rippleT * 5, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
  }

  // ═══════════════════════════════
  //  LAMP LIGHT POOLS (ground layer)
  // ═══════════════════════════════
  for (const lamp of world.lamps) {
    const flicker = 0.9 + 0.1 * Math.sin(time * 8 + lamp.x * 0.1);
    const gr = (70 + 10 * Math.sin(time * 1.2 + lamp.x * 0.02)) * flicker;
    
    // Large ground pool
    const poolGrad = ctx.createRadialGradient(lamp.x + 1, lamp.y + 30, 5, lamp.x + 1, lamp.y + 30, gr);
    poolGrad.addColorStop(0, `rgba(255, 240, 180, ${0.12 * flicker})`);
    poolGrad.addColorStop(0.5, `rgba(255, 230, 150, ${0.05 * flicker})`);
    poolGrad.addColorStop(1, 'rgba(255, 220, 120, 0)');
    ctx.fillStyle = poolGrad;
    ctx.beginPath();
    ctx.ellipse(lamp.x + 1, lamp.y + 30, gr, gr * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // ═══════════════════════════════
  //  BUILDINGS
  // ═══════════════════════════════
  for (let i = 0; i < world.buildings.length; i++) {
    const b = world.buildings[i];
    const isRest = world.restaurants.some(r => r.x === b.x && r.y === b.y);
    const isActiveRest = currentOrder && !currentOrder.pickedUp &&
      currentOrder.restaurant.x === b.x && currentOrder.restaurant.y === b.y;
    const isClientBuilding = currentOrder && currentOrder.pickedUp &&
      world.clientPoints.some(cp => cp.buildingIndex === i && cp.id === currentOrder.client.id);

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.fillRect(b.x + 6, b.y + 6, b.width, b.height);

    // Main wall
    ctx.fillStyle = isRest ? COLORS.restaurantWall : b.color;
    ctx.fillRect(b.x, b.y, b.width, b.height);

    // Roof
    ctx.fillStyle = COLORS.buildingRoof;
    ctx.fillRect(b.x - 3, b.y - 6, b.width + 6, 8);
    ctx.fillStyle = 'rgba(255,255,255,0.04)';
    ctx.fillRect(b.x - 3, b.y - 6, b.width + 6, 2);

    // Side shading
    ctx.fillStyle = 'rgba(255,255,255,0.05)';
    ctx.fillRect(b.x, b.y, 3, b.height);
    ctx.fillStyle = 'rgba(0,0,0,0.08)';
    ctx.fillRect(b.x + b.width - 3, b.y, 3, b.height);

    // Base
    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    ctx.fillRect(b.x, b.y + b.height - 3, b.width, 3);

    // ── WINDOWS ──
    const winW = 12, winH = 16, gap = 10;
    const totalW = b.windows * (winW + gap) - gap;
    const startX = b.x + (b.width - totalW) / 2;

    for (let fy = 0; fy < b.floors; fy++) {
      for (let wx = 0; wx < b.windows; wx++) {
        const windowX = startX + wx * (winW + gap);
        const windowY = b.y + 14 + fy * 26;

        ctx.fillStyle = 'rgba(0,0,0,0.15)';
        ctx.fillRect(windowX - 1, windowY - 1, winW + 2, winH + 2);

        const litSeed = (i * 7 + fy * 3 + wx * 11 + Math.floor(time / 4)) % 7;
        let winColor = COLORS.windowDark;
        let isLit = false;
        if (litSeed < 2) { winColor = COLORS.windowLit1; isLit = true; }
        else if (litSeed === 2) { winColor = COLORS.windowLit2; isLit = true; }
        else if (litSeed === 3) { winColor = COLORS.windowLit3; isLit = true; }

        ctx.fillStyle = winColor;
        ctx.fillRect(windowX, windowY, winW, winH);

        ctx.strokeStyle = COLORS.windowFrame;
        ctx.lineWidth = 1;
        ctx.strokeRect(windowX, windowY, winW, winH);
        ctx.beginPath();
        ctx.moveTo(windowX + winW / 2, windowY);
        ctx.lineTo(windowX + winW / 2, windowY + winH);
        ctx.moveTo(windowX, windowY + winH * 0.45);
        ctx.lineTo(windowX + winW, windowY + winH * 0.45);
        ctx.stroke();

        // Window glow on ground
        if (isLit) {
          const glowCol = litSeed < 2 ? 'rgba(200, 168, 74, 0.08)' : 'rgba(100, 150, 220, 0.06)';
          ctx.fillStyle = glowCol;
          ctx.fillRect(windowX - 2, windowY + winH, winW + 4, 5);
        }
      }
    }

    // ── DOOR ──
    const doorW = 18, doorH = 24;
    const doorX = b.doorX, doorY = b.y + b.height - doorH;
    ctx.fillStyle = COLORS.doorFrame;
    ctx.fillRect(doorX - 2, doorY - 2, doorW + 4, doorH + 2);
    ctx.fillStyle = COLORS.door;
    ctx.fillRect(doorX, doorY, doorW, doorH);
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 1;
    ctx.strokeRect(doorX + 2, doorY + 2, doorW - 4, doorH / 2 - 2);
    ctx.strokeRect(doorX + 2, doorY + doorH / 2 + 1, doorW - 4, doorH / 2 - 3);
    ctx.fillStyle = '#888870';
    ctx.fillRect(doorX + doorW - 5, doorY + doorH / 2 - 1, 2, 3);

    // Door light
    ctx.fillStyle = COLORS.doorLight;
    ctx.globalAlpha = 0.3 + 0.1 * Math.sin(time + i);
    ctx.fillRect(doorX - 1, doorY - 4, doorW + 2, 3);
    ctx.globalAlpha = 1;

    // Drain pipe
    if (b.width > 60) {
      ctx.fillStyle = 'rgba(80,80,90,0.6)';
      ctx.fillRect(b.x + b.width - 8, b.y + 2, 3, b.height - 2);
      ctx.fillStyle = 'rgba(60,60,70,0.4)';
      ctx.fillRect(b.x + b.width - 9, b.y + b.height - 12, 5, 12);
    }

    // ── RESTAURANT SIGN ──
    if (isRest) {
      const rest = world.restaurants.find(r => r.x === b.x && r.y === b.y);
      if (rest) {
        ctx.fillStyle = COLORS.restaurantSign;
        roundRect(ctx, b.x + 4, b.y - 22, b.width - 8, 18, 3);
        ctx.fill();
        ctx.strokeStyle = COLORS.restaurantGlow;
        ctx.lineWidth = 1;
        roundRect(ctx, b.x + 4, b.y - 22, b.width - 8, 18, 3);
        ctx.stroke();
        ctx.fillStyle = '#1a1408';
        ctx.font = 'bold 9px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(rest.name, b.x + b.width / 2, b.y - 9);

        if (isActiveRest) {
          const pulse = 0.4 + 0.5 * Math.sin(time * 5);
          ctx.strokeStyle = `rgba(255, 192, 64, ${pulse})`;
          ctx.lineWidth = 3;
          ctx.setLineDash([6, 4]);
          ctx.strokeRect(b.x - 4, b.y - 26, b.width + 8, b.height + 30);
          ctx.setLineDash([]);
          const floatY = b.y - 36 + Math.sin(time * 3) * 4;
          ctx.fillStyle = `rgba(255, 192, 64, ${0.8 + 0.2 * Math.sin(time * 4)})`;
          ctx.beginPath();
          ctx.moveTo(b.x + b.width / 2, floatY + 8);
          ctx.lineTo(b.x + b.width / 2 - 6, floatY);
          ctx.lineTo(b.x + b.width / 2 + 6, floatY);
          ctx.closePath();
          ctx.fill();
          ctx.font = 'bold 10px sans-serif';
          ctx.fillText('📍', b.x + b.width / 2, floatY - 4);
        }
      }
    }

    // ── CLIENT HIGHLIGHT ──
    if (isClientBuilding) {
      const pulse = 0.3 + 0.5 * Math.sin(time * 4);
      ctx.strokeStyle = `rgba(60, 179, 113, ${pulse})`;
      ctx.lineWidth = 3;
      ctx.setLineDash([6, 4]);
      ctx.strokeRect(b.x - 4, b.y - 4, b.width + 8, b.height + 8);
      ctx.setLineDash([]);
      ctx.fillStyle = `rgba(60, 179, 113, ${0.5 + 0.3 * Math.sin(time * 5)})`;
      ctx.fillRect(doorX - 6, b.y + b.height - 2, doorW + 12, 6);
      const floatY = b.y - 28 + Math.sin(time * 3) * 4;
      ctx.fillStyle = `rgba(60, 179, 113, ${0.8 + 0.2 * Math.sin(time * 4)})`;
      ctx.beginPath();
      ctx.moveTo(b.x + b.width / 2, floatY + 8);
      ctx.lineTo(b.x + b.width / 2 - 6, floatY);
      ctx.lineTo(b.x + b.width / 2 + 6, floatY);
      ctx.closePath();
      ctx.fill();
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🏠', b.x + b.width / 2, floatY - 4);
    }
  }

  // ═══════════════════════════════
  //  TREES (autumn)
  // ═══════════════════════════════
  for (const tree of world.trees) {
    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    ctx.beginPath();
    ctx.ellipse(tree.x + 3, tree.y + 18, 12, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Trunk sway in wind
    const sway = Math.sin(time * 1.5 + tree.x * 0.05) * windStrength * 1.5;
    ctx.fillStyle = COLORS.trunk;
    ctx.beginPath();
    ctx.moveTo(tree.x - 3, tree.y + 18);
    ctx.lineTo(tree.x + 3, tree.y + 18);
    ctx.lineTo(tree.x + 2 + sway, tree.y - 2);
    ctx.lineTo(tree.x - 2 + sway, tree.y - 2);
    ctx.closePath();
    ctx.fill();

    // Crown
    const leafColors = [COLORS.leaf1, COLORS.leaf2, COLORS.leaf3, COLORS.leaf4];
    const crownOffsets = [
      { dx: 0, dy: -12, r: 14 },
      { dx: -8, dy: -8, r: 10 },
      { dx: 8, dy: -8, r: 10 },
      { dx: -4, dy: -16, r: 9 },
      { dx: 5, dy: -15, r: 8 },
    ];
    for (let ci = 0; ci < crownOffsets.length; ci++) {
      const co = crownOffsets[ci];
      const wobble = Math.sin(time * 2 + tree.x * 0.1 + ci) * windStrength * 2;
      ctx.fillStyle = leafColors[(ci + Math.floor(tree.x)) % leafColors.length];
      ctx.beginPath();
      ctx.arc(tree.x + co.dx + sway + wobble * 0.3, tree.y + co.dy, co.r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Highlight
    ctx.fillStyle = 'rgba(255,200,100,0.08)';
    ctx.beginPath();
    ctx.arc(tree.x - 3 + sway, tree.y - 14, 7, 0, Math.PI * 2);
    ctx.fill();
  }

  // ═══════════════════════════════
  //  STREET LAMPS (lamp heads)
  // ═══════════════════════════════
  for (const lamp of world.lamps) {
    const flicker = 0.9 + 0.1 * Math.sin(time * 8 + lamp.x * 0.1);
    
    // Pole
    ctx.fillStyle = COLORS.lamp;
    ctx.fillRect(lamp.x, lamp.y, 3, 28);
    ctx.fillRect(lamp.x - 5, lamp.y, 13, 2);

    // Lamp housing
    ctx.fillStyle = '#404040';
    ctx.fillRect(lamp.x - 5, lamp.y - 4, 13, 5);

    // Light bulb
    ctx.fillStyle = `rgba(255, 240, 180, ${0.9 * flicker})`;
    ctx.fillRect(lamp.x - 3, lamp.y - 2, 9, 3);

    // Glow around lamp
    const gr = 50 + 8 * Math.sin(time * 1.5 + lamp.x * 0.01);
    const grd = ctx.createRadialGradient(lamp.x + 1, lamp.y, 3, lamp.x + 1, lamp.y, gr);
    grd.addColorStop(0, `rgba(255, 240, 180, ${0.35 * flicker})`);
    grd.addColorStop(0.3, `rgba(255, 230, 150, ${0.15 * flicker})`);
    grd.addColorStop(1, 'rgba(255, 220, 120, 0)');
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.arc(lamp.x + 1, lamp.y, gr, 0, Math.PI * 2);
    ctx.fill();
  }

  // ═══════════════════════════════
  //  CLIENT DELIVERY POINTS
  // ═══════════════════════════════
  for (const cp of world.clientPoints) {
    const isActive = currentOrder && currentOrder.pickedUp && currentOrder.client.id === cp.id;
    if (isActive) {
      const pulse = 0.4 + 0.3 * Math.sin(time * 5);
      ctx.fillStyle = `rgba(60, 179, 113, ${pulse * 0.5})`;
      ctx.fillRect(cp.x - 6, cp.y - 6, cp.width + 12, cp.height + 12);
      ctx.strokeStyle = `rgba(80, 232, 144, ${pulse})`;
      ctx.lineWidth = 2;
      ctx.strokeRect(cp.x - 6, cp.y - 6, cp.width + 12, cp.height + 12);
      const bounceY = cp.y - 28 + Math.sin(time * 4) * 5;
      ctx.fillStyle = COLORS.clientGlow;
      ctx.beginPath();
      ctx.moveTo(cp.x + cp.width / 2, bounceY + 10);
      ctx.lineTo(cp.x + cp.width / 2 - 7, bounceY);
      ctx.lineTo(cp.x + cp.width / 2 + 7, bounceY);
      ctx.closePath();
      ctx.fill();
    }
  }

  // ═══════════════════════════════
  //  CARS
  // ═══════════════════════════════
  for (const car of world.cars) {
    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.fillRect(car.x + 3, car.y + 3, car.width, car.height);

    ctx.fillStyle = car.color;
    roundRect(ctx, car.x, car.y, car.width, car.height, 4);
    ctx.fill();

    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    if (car.direction === 'horizontal') {
      roundRect(ctx, car.x + 10, car.y + 3, car.width - 20, car.height - 6, 3);
      ctx.fill();
      ctx.fillStyle = COLORS.carWindow;
      ctx.fillRect(car.x + 12, car.y + 4, car.width / 3 - 6, car.height - 8);
      ctx.fillRect(car.x + car.width / 3 + 8, car.y + 4, car.width / 3 - 6, car.height - 8);
    } else {
      roundRect(ctx, car.x + 3, car.y + 10, car.width - 6, car.height - 20, 3);
      ctx.fill();
      ctx.fillStyle = COLORS.carWindow;
      ctx.fillRect(car.x + 4, car.y + 12, car.width - 8, car.height / 3 - 6);
      ctx.fillRect(car.x + 4, car.y + car.height / 3 + 8, car.width - 8, car.height / 3 - 6);
    }

    // Lights
    if (car.direction === 'horizontal') {
      const frontX = car.dirSign > 0 ? car.x + car.width - 3 : car.x;
      const backX = car.dirSign > 0 ? car.x : car.x + car.width - 3;
      ctx.fillStyle = COLORS.carHeadlight;
      ctx.fillRect(frontX, car.y + 3, 3, 4);
      ctx.fillRect(frontX, car.y + car.height - 7, 3, 4);
      // Headlight beam
      ctx.fillStyle = 'rgba(240, 232, 128, 0.06)';
      const glowDir = car.dirSign > 0 ? 1 : -1;
      ctx.beginPath();
      ctx.moveTo(frontX + glowDir * 3, car.y + 2);
      ctx.lineTo(frontX + glowDir * 3, car.y + car.height - 2);
      ctx.lineTo(frontX + glowDir * 50, car.y + car.height / 2 + 15);
      ctx.lineTo(frontX + glowDir * 50, car.y + car.height / 2 - 15);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = COLORS.carTaillight;
      ctx.fillRect(backX, car.y + 3, 3, 4);
      ctx.fillRect(backX, car.y + car.height - 7, 3, 4);
    } else {
      const frontY = car.dirSign > 0 ? car.y + car.height - 3 : car.y;
      const backY = car.dirSign > 0 ? car.y : car.y + car.height - 3;
      ctx.fillStyle = COLORS.carHeadlight;
      ctx.fillRect(car.x + 3, frontY, 4, 3);
      ctx.fillRect(car.x + car.width - 7, frontY, 4, 3);
      ctx.fillStyle = 'rgba(240, 232, 128, 0.06)';
      const glowDir = car.dirSign > 0 ? 1 : -1;
      ctx.beginPath();
      ctx.moveTo(car.x + 2, frontY + glowDir * 3);
      ctx.lineTo(car.x + car.width - 2, frontY + glowDir * 3);
      ctx.lineTo(car.x + car.width / 2 + 15, frontY + glowDir * 50);
      ctx.lineTo(car.x + car.width / 2 - 15, frontY + glowDir * 50);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = COLORS.carTaillight;
      ctx.fillRect(car.x + 3, backY, 4, 3);
      ctx.fillRect(car.x + car.width - 7, backY, 4, 3);
    }
  }

  // ═══════════════════════════════
  //  PLAYER
  // ═══════════════════════════════
  drawPlayer(ctx, player, time);

  // ═══════════════════════════════
  //  DIRECTION ARROW
  // ═══════════════════════════════
  if (currentOrder) {
    let targetX: number, targetY: number;
    let arrowColor: string;
    if (!currentOrder.pickedUp) {
      targetX = currentOrder.restaurant.x + currentOrder.restaurant.width / 2;
      targetY = currentOrder.restaurant.y + currentOrder.restaurant.height / 2;
      arrowColor = COLORS.restaurantGlow;
    } else {
      targetX = currentOrder.client.x + currentOrder.client.width / 2;
      targetY = currentOrder.client.y + currentOrder.client.height / 2;
      arrowColor = COLORS.clientGlow;
    }

    const dx = targetX - player.x;
    const dy = targetY - player.y;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist > 120) {
      const angle = Math.atan2(dy, dx);
      const arrowDist = 55;
      const ax = player.x + Math.cos(angle) * arrowDist;
      const ay = player.y - 10 + Math.sin(angle) * arrowDist;

      ctx.save();
      ctx.globalAlpha = 0.15 + 0.1 * Math.sin(time * 3);
      ctx.strokeStyle = arrowColor;
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 6]);
      ctx.beginPath();
      ctx.moveTo(player.x, player.y - 10);
      ctx.lineTo(ax, ay);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
      ctx.restore();

      ctx.save();
      ctx.translate(ax, ay);
      ctx.rotate(angle);
      ctx.fillStyle = arrowColor;
      ctx.globalAlpha = 0.7 + 0.3 * Math.sin(time * 4);
      ctx.beginPath();
      ctx.moveTo(14, 0);
      ctx.lineTo(-5, -8);
      ctx.lineTo(-2, 0);
      ctx.lineTo(-5, 8);
      ctx.closePath();
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.restore();

      const meters = Math.floor(dist / 10);
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillText(`${meters}м`, ax + 1, ay - 11);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`${meters}м`, ax, ay - 12);
    }
  }

  // ═══════════════════════════════
  //  RAIN (with wind)
  // ═══════════════════════════════
  drawRain(ctx, camera, canvasW, canvasH, time);

  // ═══════════════════════════════
  //  FALLING LEAVES
  // ═══════════════════════════════
  drawLeaves(ctx, camera, canvasW, canvasH, time);

  ctx.restore();

  // ═══════════════════════════════
  //  POST-PROCESSING
  // ═══════════════════════════════
  // Fog
  ctx.fillStyle = COLORS.fog;
  ctx.fillRect(0, 0, canvasW, canvasH);

  // Vignette
  const vigGrad = ctx.createRadialGradient(
    canvasW / 2, canvasH / 2, canvasW * 0.25,
    canvasW / 2, canvasH / 2, canvasW * 0.75
  );
  vigGrad.addColorStop(0, 'rgba(0,0,0,0)');
  vigGrad.addColorStop(1, 'rgba(0,0,0,0.45)');
  ctx.fillStyle = vigGrad;
  ctx.fillRect(0, 0, canvasW, canvasH);
}

// ════════════════════════════════════
//  PLAYER
// ════════════════════════════════════
function drawPlayer(ctx: CanvasRenderingContext2D, player: Player, time: number) {
  const px = player.x;
  const py = player.y;
  const moving = player.isMoving;
  const sprint = player.isSprinting;
  const bobY = moving ? Math.sin(time * (sprint ? 16 : 12)) * (sprint ? 3 : 2) : 0;
  const bobX = moving ? Math.cos(time * (sprint ? 16 : 12)) * 1.2 : 0;
  const legCycle = moving ? Math.sin(time * (sprint ? 18 : 14)) : 0;

  // Shadow
  ctx.fillStyle = 'rgba(0,0,0,0.25)';
  ctx.beginPath();
  ctx.ellipse(px, py + 4, 11, 4, 0, 0, Math.PI * 2);
  ctx.fill();

  // Sprint dust
  if (sprint && moving) {
    for (let d = 0; d < 3; d++) {
      const dustAge = (time * 10 + d * 2.1) % 3;
      if (dustAge < 1.5) {
        ctx.fillStyle = `rgba(120, 110, 90, ${0.2 * (1 - dustAge / 1.5)})`;
        ctx.beginPath();
        ctx.arc(
          px - (player.direction === 'right' ? 1 : -1) * dustAge * 6 + Math.sin(d * 7) * 4,
          py + 2 + dustAge * 3, 2 + dustAge * 2, 0, Math.PI * 2
        );
        ctx.fill();
      }
    }
  }

  // Legs
  const legSpread = legCycle * (sprint ? 6 : 4);
  ctx.fillStyle = COLORS.pants;
  ctx.fillRect(px - 4 - legSpread, py - 4, 4, 9);
  ctx.fillRect(px + legSpread, py - 4, 4, 9);
  ctx.fillStyle = COLORS.shoes;
  ctx.fillRect(px - 5 - legSpread, py + 3, 6, 3);
  ctx.fillRect(px - 1 + legSpread, py + 3, 6, 3);
  ctx.fillStyle = 'rgba(255,255,255,0.1)';
  ctx.fillRect(px - 5 - legSpread, py + 3, 6, 1);
  ctx.fillRect(px - 1 + legSpread, py + 3, 6, 1);

  // Body
  ctx.fillStyle = COLORS.playerJacket;
  ctx.fillRect(px - 7 + bobX, py - 20 + bobY, 14, 17);
  ctx.fillStyle = COLORS.playerDark;
  ctx.fillRect(px - 0.5 + bobX, py - 20 + bobY, 1.5, 17);
  ctx.fillStyle = COLORS.player;
  ctx.fillRect(px - 7 + bobX, py - 22 + bobY, 14, 4);
  ctx.fillStyle = COLORS.playerJacket;
  ctx.fillRect(px - 9 + bobX, py - 18 + bobY, 3, 10);
  ctx.fillRect(px + 6 + bobX, py - 18 + bobY, 3, 10);

  // Backpack
  ctx.fillStyle = COLORS.backpack;
  roundRect(ctx, px - 11 + bobX, py - 30 + bobY, 22, 24, 3);
  ctx.fill();
  ctx.strokeStyle = COLORS.backpackStrap;
  ctx.lineWidth = 1;
  roundRect(ctx, px - 11 + bobX, py - 30 + bobY, 22, 24, 3);
  ctx.stroke();
  ctx.fillStyle = COLORS.backpackDark;
  ctx.fillRect(px - 10 + bobX, py - 12 + bobY, 20, 6);
  ctx.fillStyle = '#1a1408';
  ctx.font = 'bold 7px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('ЕДА', px + bobX, py - 17 + bobY);
  ctx.strokeStyle = COLORS.backpackStrap;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(px - 6 + bobX, py - 28 + bobY);
  ctx.lineTo(px - 5 + bobX, py - 18 + bobY);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(px + 6 + bobX, py - 28 + bobY);
  ctx.lineTo(px + 5 + bobX, py - 18 + bobY);
  ctx.stroke();

  // Inventory indicator
  if (player.inventory) {
    ctx.fillStyle = '#e84040';
    ctx.beginPath();
    ctx.arc(px + 12 + bobX, py - 28 + bobY, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 7px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('!', px + 12 + bobX, py - 26 + bobY);
  }

  // Head
  ctx.fillStyle = COLORS.skin;
  ctx.beginPath();
  ctx.arc(px + bobX, py - 28 + bobY, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = COLORS.skinDark;
  ctx.beginPath();
  ctx.arc(px + 4 + bobX, py - 26 + bobY, 3, 0, Math.PI * 2);
  ctx.fill();

  // Cap
  ctx.fillStyle = COLORS.player;
  ctx.beginPath();
  ctx.arc(px + bobX, py - 30 + bobY, 8, Math.PI, 0);
  ctx.fill();
  ctx.fillStyle = COLORS.playerDark;
  ctx.fillRect(px - 9 + bobX, py - 31 + bobY, 18, 3);
  ctx.fillStyle = '#1a1408';
  ctx.beginPath();
  ctx.arc(px + bobX, py - 33 + bobY, 2, 0, Math.PI * 2);
  ctx.fill();

  // Eyes
  const eyeDir = player.direction === 'left' ? -2.5 : player.direction === 'right' ? 2.5 : 0;
  const eyeY = player.direction === 'up' ? -1 : 0;
  ctx.fillStyle = '#fff';
  ctx.fillRect(px - 4 + eyeDir + bobX, py - 30 + eyeY + bobY, 3, 3);
  ctx.fillRect(px + 1 + eyeDir + bobX, py - 30 + eyeY + bobY, 3, 3);
  ctx.fillStyle = '#1a1a2a';
  ctx.fillRect(px - 3 + eyeDir + bobX, py - 29 + eyeY + bobY, 2, 2);
  ctx.fillRect(px + 2 + eyeDir + bobX, py - 29 + eyeY + bobY, 2, 2);

  // ══════ BREATH STEAM ══════
  // Only when standing still or moving slowly, and random intervals
  const breathPhase = (time * 0.8) % 4;
  if (breathPhase < 1.5 && !sprint) {
    const breathAlpha = (1 - breathPhase / 1.5) * 0.4;
    const breathX = px + bobX + (player.direction === 'left' ? -5 : player.direction === 'right' ? 5 : 0);
    const breathY = py - 25 + bobY;
    
    for (let p = 0; p < 4; p++) {
      const pAge = breathPhase + p * 0.15;
      if (pAge < 1.5) {
        const pAlpha = (1 - pAge / 1.5) * breathAlpha;
        const pX = breathX + pAge * 3 * windStrength + Math.sin(pAge * 3 + p) * 2;
        const pY = breathY - pAge * 5 + Math.cos(pAge * 2 + p * 1.5) * 1.5;
        const pSize = 1.5 + pAge * 2;
        
        ctx.fillStyle = `rgba(200, 210, 230, ${pAlpha})`;
        ctx.beginPath();
        ctx.arc(pX, pY, pSize, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  // Phrase bubble
  if (player.phrase) {
    ctx.font = '10px sans-serif';
    const metrics = ctx.measureText(player.phrase);
    const bw = metrics.width + 18;
    const bh = 22;
    const bx = px - bw / 2;
    const by = py - 56 + bobY;
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    roundRect(ctx, bx, by, bw, bh, 8);
    ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.1)';
    ctx.lineWidth = 1;
    roundRect(ctx, bx, by, bw, bh, 8);
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.beginPath();
    ctx.moveTo(px - 4, by + bh);
    ctx.lineTo(px, by + bh + 6);
    ctx.lineTo(px + 4, by + bh);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#222';
    ctx.textAlign = 'center';
    ctx.fillText(player.phrase, px, by + 15);
  }

  // Low energy
  if (player.energy < 20) {
    const warnAlpha = 0.5 + 0.4 * Math.sin(time * 6);
    ctx.fillStyle = `rgba(255, 60, 60, ${warnAlpha})`;
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('⚡ УСТАЛ', px, py - 60);
  }
}

// ════════════════════════════════════
//  RAIN (with wind angle)
// ════════════════════════════════════
function drawRain(
  ctx: CanvasRenderingContext2D,
  camera: Camera,
  canvasW: number,
  canvasH: number,
  time: number,
) {
  const rainLen = 14 + windStrength * 4;
  const rainDx = Math.sin(windAngle) * rainLen;
  const rainDy = Math.cos(windAngle) * rainLen;

  ctx.strokeStyle = 'rgba(140, 160, 200, 0.15)';
  ctx.lineWidth = 1;
  
  const seed = Math.floor(time * 70);
  for (let i = 0; i < 250; i++) {
    const rx = ((seed * 7 + i * 137) % (canvasW + 60)) + camera.x - 30;
    const ry = ((seed * 3 + i * 91 + i * 17) % (canvasH + 60)) + camera.y - 30;
    ctx.beginPath();
    ctx.moveTo(rx, ry);
    ctx.lineTo(rx - rainDx, ry + rainDy);
    ctx.stroke();
  }

  // Splash effect on ground (random splashes)
  ctx.fillStyle = 'rgba(140, 160, 200, 0.08)';
  for (let s = 0; s < 30; s++) {
    const splashT = (time * 5 + s * 1.37) % 1;
    if (splashT < 0.3) {
      const sx = ((s * 271 + Math.floor(time * 5) * 37) % canvasW) + camera.x;
      const sy = ((s * 193 + Math.floor(time * 5) * 53) % canvasH) + camera.y;
      const sr = splashT * 6;
      ctx.beginPath();
      ctx.arc(sx, sy, sr, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

// ════════════════════════════════════
//  FALLING LEAVES (wind-driven)
// ════════════════════════════════════
function drawLeaves(
  ctx: CanvasRenderingContext2D,
  camera: Camera,
  canvasW: number,
  canvasH: number,
  time: number,
) {
  const leafColors = ['#8a5a20', '#a06828', '#6a4a18', '#c07830', '#7a4a10'];
  
  for (let i = 0; i < 35; i++) {
    const baseSpeed = 0.3 + (i % 5) * 0.1;
    const phase = time * baseSpeed + i * 1.7;
    
    // Horizontal drift with wind
    const drift = Math.sin(phase * 2) * 30 + windStrength * 40 * Math.sin(phase * 0.7);
    const lx = ((i * 317 + Math.floor(phase * 0.3) * 200) % (canvasW + 200)) + camera.x - 100 + drift;
    const ly = ((phase * 25) % (canvasH + 100)) + camera.y - 50;
    
    // Rotation
    const rot = Math.sin(phase * 3) * 1.5 + windAngle;
    
    // Size variation
    const size = 3 + (i % 4);
    
    // Tumble effect
    const tumble = Math.cos(phase * 4) * 0.3;

    ctx.save();
    ctx.translate(lx, ly);
    ctx.rotate(rot);
    ctx.scale(1, 0.6 + tumble * 0.4);
    
    ctx.fillStyle = leafColors[i % leafColors.length];
    ctx.globalAlpha = 0.6 + 0.2 * Math.sin(phase);
    
    // Leaf shape
    ctx.beginPath();
    ctx.ellipse(0, 0, size, size * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();
    
    // Leaf vein
    ctx.strokeStyle = 'rgba(0,0,0,0.1)';
    ctx.lineWidth = 0.5;
    ctx.beginPath();
    ctx.moveTo(-size * 0.8, 0);
    ctx.lineTo(size * 0.8, 0);
    ctx.stroke();
    
    ctx.globalAlpha = 1;
    ctx.restore();
  }
}

// ════════════════════════════════════
//  UTIL
// ════════════════════════════════════
function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number, y: number, w: number, h: number, r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}
