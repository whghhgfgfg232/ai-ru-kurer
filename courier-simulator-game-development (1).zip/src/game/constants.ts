import { ShopItem, Player } from './types';

export const WORLD_WIDTH = 3200;
export const WORLD_HEIGHT = 2400;
export const TILE = 64;

export const COLORS = {
  // Environment
  road: '#383840',
  roadDark: '#2e2e36',
  roadLine: '#6e6e44',
  roadLineWhite: '#888878',
  sidewalk: '#5a5a60',
  sidewalkLight: '#686870',
  sidewalkTile: '#4e4e56',
  curb: '#707078',
  
  // Buildings
  building1: '#4a4a5a',
  building2: '#525264',
  building3: '#5c5c6e',
  building4: '#484858',
  building5: '#565668',
  buildingRoof: '#3a3a48',
  buildingAccent: '#6a6a7e',
  
  // Windows
  windowDark: '#1e2a44',
  windowLit1: '#c8a84a',
  windowLit2: '#80b0e8',
  windowLit3: '#d8c868',
  windowFrame: '#2a2a38',
  
  // Doors
  door: '#3a3020',
  doorFrame: '#4a4038',
  doorLight: '#c8a84a',
  
  // Nature
  grass1: '#2a3620',
  grass2: '#324028',
  grass3: '#263018',
  mud: '#3a3428',
  
  // Restaurant
  restaurant: '#9a5c10',
  restaurantWall: '#b87418',
  restaurantSign: '#e8a83e',
  restaurantGlow: '#ffc040',
  
  // Client
  client: '#2e8b57',
  clientLight: '#3cb371',
  clientGlow: '#50e890',
  
  // Water
  puddle: '#222e48',
  puddleRim: '#2a3656',
  puddleShine: '#4a5a80',
  
  // Trees (autumn)
  trunk: '#3a2a18',
  trunkDark: '#2a1e10',
  leaf1: '#6a4a18',
  leaf2: '#8a5a20',
  leaf3: '#a06828',
  leaf4: '#4a3a14',
  
  // Street furniture
  lamp: '#606058',
  lampLight: '#e8d878',
  lampGlow: '#f0e090',
  bench: '#5a4a30',
  bin: '#404848',
  
  // Player
  player: '#f0d020',
  playerDark: '#d0b010',
  playerJacket: '#e8c818',
  backpack: '#dab818',
  backpackStrap: '#b09010',
  backpackDark: '#c0a010',
  skin: '#d4a574',
  skinDark: '#b8905c',
  pants: '#1a1a2e',
  shoes: '#101020',
  
  // Cars
  car1: '#8b2020',
  car2: '#1a3868',
  car3: '#404848',
  car4: '#2a4a2a',
  car5: '#5a2a5a',
  carWindow: '#1a2a40',
  carHeadlight: '#f0e880',
  carTaillight: '#e04040',
  
  // Atmosphere
  fog: 'rgba(20, 22, 34, 0.12)',
  skyTint: '#1a1c28',
};

export const FOOD_NAMES = [
  'Шаурма на углях',
  'Бургер Двойной',
  'Пицца Маргарита',
  'Роллы Филадельфия',
  'Лагман острый',
  'Чебуреки 3 шт.',
  'WOK с курицей',
  'Хинкали 5 шт.',
  'Том Ям',
  'Фалафель',
  'Шашлык свиной',
  'Плов узбекский',
  'Борщ домашний',
  'Пельмени 12 шт.',
];

export const PHRASES = [
  'Холодно...',
  'Где этот подъезд?',
  'Вкусна и точка',
  'Опять дождь...',
  'Ноги промокли',
  'Ещё один заказ...',
  'Хочу домой',
  'Тут нет домофона!',
  'Пробка на дороге...',
  'Лифт не работает...',
  'Хорошие чаевые бы...',
  'Скоро на перерыв',
  'Интересно, там вкусно?',
  'А мне кто закажет?',
  'Навигатор врёт!',
  'Жизнь — боль',
  'Лужа... опять...',
  'Может, на Ozon?',
];

export const CAR_COLORS = [COLORS.car1, COLORS.car2, COLORS.car3, COLORS.car4, COLORS.car5];

export const SHOP_ITEMS: ShopItem[] = [
  {
    id: 'energy_drink',
    name: 'Энергетик «Ягуар»',
    description: 'Восстанавливает +40% энергии',
    price: 80,
    icon: '⚡',
    action: (p: Player) => { p.energy = Math.min(100, p.energy + 40); },
    canBuy: (p: Player) => p.balance >= 80 && p.energy < 100,
  },
  {
    id: 'shawarma',
    name: 'Шаурма для себя',
    description: 'Вкусная! +25% энергии',
    price: 50,
    icon: '🌯',
    action: (p: Player) => { p.energy = Math.min(100, p.energy + 25); },
    canBuy: (p: Player) => p.balance >= 50 && p.energy < 100,
  },
  {
    id: 'sneakers',
    name: 'Кроссовки Nike',
    description: 'Скорость передвижения +15%',
    price: 300,
    icon: '👟',
    action: (p: Player) => {
      p.upgrades.speedLevel++;
      p.baseSpeed = 160 + p.upgrades.speedLevel * 24;
    },
    canBuy: (p: Player) => p.balance >= 300 && p.upgrades.speedLevel < 5,
  },
  {
    id: 'coffee',
    name: 'Кофе из автомата',
    description: 'Бодрит немного. +15% энергии',
    price: 30,
    icon: '☕',
    action: (p: Player) => { p.energy = Math.min(100, p.energy + 15); },
    canBuy: (p: Player) => p.balance >= 30 && p.energy < 100,
  },
  {
    id: 'raincoat',
    name: 'Термо-дождевик',
    description: 'Расход энергии −20%',
    price: 200,
    icon: '🧥',
    action: (_p: Player) => {
      // Tracked via raincoatCount in engine
    },
    canBuy: (p: Player) => p.balance >= 200,
  },
];
