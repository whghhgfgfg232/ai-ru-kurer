// ═══════════════════════════════════════════════
//  AUDIO ENGINE — Web Audio API for game sounds
// ═══════════════════════════════════════════════

let audioCtx: AudioContext | null = null;
let masterGain: GainNode | null = null;
let initialized = false;

// Sound state
let stepPhase = 0;
let lastStepTime = 0;
let ambientRainGain: GainNode | null = null;

export function initAudio() {
  if (initialized) return;
  try {
    audioCtx = new AudioContext();
    masterGain = audioCtx.createGain();
    masterGain.gain.value = 0.3;
    masterGain.connect(audioCtx.destination);
    initialized = true;
    startAmbientRain();
  } catch (e) {
    console.warn('Audio not supported');
  }
}

export function resumeAudio() {
  if (audioCtx?.state === 'suspended') {
    audioCtx.resume();
  }
}

// ── FOOTSTEPS ──
export function playFootstep(isSprinting: boolean, time: number) {
  if (!audioCtx || !masterGain) return;
  
  const interval = isSprinting ? 0.18 : 0.32;
  if (time - lastStepTime < interval) return;
  lastStepTime = time;
  stepPhase = (stepPhase + 1) % 2;

  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  const filter = audioCtx.createBiquadFilter();

  // Crunchy footstep sound
  osc.type = 'sawtooth';
  osc.frequency.value = 60 + stepPhase * 15 + Math.random() * 20;

  filter.type = 'lowpass';
  filter.frequency.value = 200 + Math.random() * 100;
  filter.Q.value = 1;

  gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.08);

  osc.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);

  osc.start();
  osc.stop(audioCtx.currentTime + 0.1);
}

// ── CAR PASSING ──
export function playCarPass(distance: number) {
  if (!audioCtx || !masterGain) return;
  if (distance > 200) return;

  const volume = Math.max(0.01, 0.06 * (1 - distance / 200));
  
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  const filter = audioCtx.createBiquadFilter();

  osc.type = 'sawtooth';
  osc.frequency.value = 80 + Math.random() * 30;

  filter.type = 'lowpass';
  filter.frequency.value = 300;

  gain.gain.setValueAtTime(volume, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.5);

  osc.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);

  osc.start();
  osc.stop(audioCtx.currentTime + 0.5);
}

// ── PICKUP / DELIVERY ──
export function playPickup() {
  if (!audioCtx || !masterGain) return;
  playTone(440, 0.08, 0.12);
  setTimeout(() => playTone(554, 0.06, 0.1), 80);
  setTimeout(() => playTone(659, 0.05, 0.1), 160);
}

export function playDelivery() {
  if (!audioCtx || !masterGain) return;
  playTone(523, 0.1, 0.15);
  setTimeout(() => playTone(659, 0.08, 0.12), 100);
  setTimeout(() => playTone(784, 0.1, 0.2), 200);
  setTimeout(() => playTone(1047, 0.08, 0.25), 350);
}

export function playFail() {
  if (!audioCtx || !masterGain) return;
  playTone(200, 0.1, 0.3);
  setTimeout(() => playTone(150, 0.1, 0.4), 150);
}

function playTone(freq: number, vol: number, dur: number) {
  if (!audioCtx || !masterGain) return;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'sine';
  osc.frequency.value = freq;
  gain.gain.setValueAtTime(vol, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + dur);
  osc.connect(gain);
  gain.connect(masterGain);
  osc.start();
  osc.stop(audioCtx.currentTime + dur);
}

// ── AMBIENT RAIN ──
function startAmbientRain() {
  if (!audioCtx || !masterGain) return;

  // White noise for rain
  const bufferSize = audioCtx.sampleRate * 2;
  const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = (Math.random() * 2 - 1) * 0.5;
  }

  const noise = audioCtx.createBufferSource();
  noise.buffer = buffer;
  noise.loop = true;

  const filter = audioCtx.createBiquadFilter();
  filter.type = 'bandpass';
  filter.frequency.value = 800;
  filter.Q.value = 0.5;

  ambientRainGain = audioCtx.createGain();
  ambientRainGain.gain.value = 0.015;

  noise.connect(filter);
  filter.connect(ambientRainGain);
  ambientRainGain.connect(masterGain);
  noise.start();
}

// ── COLLISION ──
export function playHit() {
  if (!audioCtx || !masterGain) return;
  
  const noise = audioCtx.createBufferSource();
  const bufferSize = audioCtx.sampleRate * 0.3;
  const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.1));
  }
  noise.buffer = buffer;

  const gain = audioCtx.createGain();
  gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);

  const filter = audioCtx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = 400;

  noise.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);
  noise.start();
}
