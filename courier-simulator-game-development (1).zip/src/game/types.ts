// ===== GAME TYPES =====

export interface Vec2 {
  x: number;
  y: number;
}

export interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  speed: number;
  baseSpeed: number;
  energy: number;
  balance: number;
  inventory: Order | null;
  direction: 'up' | 'down' | 'left' | 'right';
  isMoving: boolean;
  isSprinting: boolean;
  phrase: string | null;
  phraseTimer: number;
  upgrades: {
    speedLevel: number;
  };
  dead: boolean;
  deathReason: string;
  animFrame: number;
  animTimer: number;
}

export interface Order {
  id: number;
  name: string;
  reward: number;
  penalty: number;
  restaurant: Restaurant;
  client: ClientPoint;
  timeLimit: number; // seconds
  timer: number; // current time elapsed
  pickedUp: boolean;
  status: 'waiting' | 'picked_up' | 'delivered' | 'failed';
}

export interface Restaurant {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  name: string;
}

export interface ClientPoint {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  buildingIndex: number;
}

export interface Building {
  x: number;
  y: number;
  width: number;
  height: number;
  floors: number;
  windows: number;
  color: string;
  doorX: number;
}

export interface Car {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  direction: 'horizontal' | 'vertical';
  dirSign: number; // 1 or -1
  color: string;
  lane: number;
}

export interface Road {
  x: number;
  y: number;
  width: number;
  height: number;
  direction: 'horizontal' | 'vertical';
}

export interface GameNotification {
  id: number;
  text: string;
  timer: number;
  type: 'order' | 'success' | 'fail' | 'info';
}

export type GameState = 'menu' | 'playing' | 'paused' | 'gameover' | 'shop';

export interface GameWorld {
  width: number;
  height: number;
  buildings: Building[];
  roads: Road[];
  restaurants: Restaurant[];
  clientPoints: ClientPoint[];
  cars: Car[];
  sidewalks: { x: number; y: number; width: number; height: number }[];
  puddles: { x: number; y: number; radius: number }[];
  trees: { x: number; y: number }[];
  lamps: { x: number; y: number }[];
}

export interface Camera {
  x: number;
  y: number;
}

export interface Keys {
  [key: string]: boolean;
}

export interface ShopItem {
  id: string;
  name: string;
  description: string;
  price: number;
  icon: string;
  action: (player: Player) => void;
  canBuy: (player: Player) => boolean;
}
