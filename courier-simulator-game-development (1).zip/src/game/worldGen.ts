import { GameWorld, Road, Car } from './types';
import { WORLD_WIDTH, WORLD_HEIGHT, COLORS, CAR_COLORS } from './constants';

function rand(a: number, b: number) { return Math.random() * (b - a) + a; }
function randInt(a: number, b: number) { return Math.floor(rand(a, b)); }

export function generateWorld(): GameWorld {
  const roads: Road[] = [];
  const buildings: GameWorld['buildings'] = [];
  const restaurants: GameWorld['restaurants'] = [];
  const clientPoints: GameWorld['clientPoints'] = [];
  const cars: Car[] = [];
  const sidewalks: GameWorld['sidewalks'] = [];
  const puddles: GameWorld['puddles'] = [];
  const trees: GameWorld['trees'] = [];
  const lamps: GameWorld['lamps'] = [];

  const ROAD_W = 80;
  const SW_W = 32;
  const BLOCK_W = 480;
  const BLOCK_H = 400;
  const MARGIN = 120;

  const hRoadYs: number[] = [];
  for (let r = 0; r < 5; r++) {
    const y = MARGIN + r * (BLOCK_H + ROAD_W);
    hRoadYs.push(y);
    roads.push({ x: 0, y, width: WORLD_WIDTH, height: ROAD_W, direction: 'horizontal' });
    sidewalks.push({ x: 0, y: y - SW_W, width: WORLD_WIDTH, height: SW_W });
    sidewalks.push({ x: 0, y: y + ROAD_W, width: WORLD_WIDTH, height: SW_W });
  }

  const vRoadXs: number[] = [];
  for (let c = 0; c < 6; c++) {
    const x = MARGIN + c * (BLOCK_W + ROAD_W);
    vRoadXs.push(x);
    roads.push({ x, y: 0, width: ROAD_W, height: WORLD_HEIGHT, direction: 'vertical' });
    sidewalks.push({ x: x - SW_W, y: 0, width: SW_W, height: WORLD_HEIGHT });
    sidewalks.push({ x: x + ROAD_W, y: 0, width: SW_W, height: WORLD_HEIGHT });
  }

  let bId = 0, rId = 0, cId = 0;
  const bColors = [COLORS.building1, COLORS.building2, COLORS.building3, COLORS.building4, COLORS.building5];
  const restNames = ['Шаурмичная «У Ашота»', 'Бургер Кинг', 'Пицца Хат', 'WOK Кафе', 'Чебуречная №1', 'Суши Мастер', 'Столовая №5', 'Хинкальная'];

  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < 5; col++) {
      const bx0 = vRoadXs[col] + ROAD_W + SW_W + 10;
      const by0 = hRoadYs[row] + ROAD_W + SW_W + 10;
      const bx1 = (col + 1 < vRoadXs.length ? vRoadXs[col + 1] : WORLD_WIDTH) - SW_W - 10;
      const by1 = (row + 1 < hRoadYs.length ? hRoadYs[row + 1] : WORLD_HEIGHT) - SW_W - 10;
      const aw = bx1 - bx0, ah = by1 - by0;
      if (aw < 100 || ah < 100) continue;

      const n = randInt(2, 5);
      const bw = Math.min(180, aw / n - 10);

      for (let i = 0; i < n; i++) {
        const bx = bx0 + i * (bw + 10);
        const bh = randInt(100, Math.min(200, ah - 20));
        const by = by0 + randInt(0, Math.max(0, ah - bh - 20));
        const floors = Math.max(2, Math.floor(bh / 28));
        const windows = Math.max(2, Math.floor(bw / 30));
        const color = bColors[randInt(0, bColors.length)];
        const doorX = bx + bw / 2 - 10;

        buildings.push({ x: bx, y: by, width: bw, height: bh, floors, windows, color, doorX });
        bId++;

        if (rId < 8 && Math.random() < 0.15) {
          restaurants.push({ id: rId, x: bx, y: by, width: bw, height: bh, name: restNames[rId % restNames.length] });
          rId++;
        }

        if (Math.random() < 0.5) {
          clientPoints.push({ id: cId++, x: doorX - 5, y: by + bh - 10, width: 30, height: 20, buildingIndex: bId - 1 });
        }
      }
    }
  }

  while (restaurants.length < 5) {
    const b = buildings[randInt(0, buildings.length)];
    restaurants.push({ id: rId++, x: b.x, y: b.y, width: b.width, height: b.height, name: restNames[rId % restNames.length] });
  }
  while (clientPoints.length < 15) {
    const bi = randInt(0, buildings.length);
    const b = buildings[bi];
    clientPoints.push({ id: cId++, x: b.doorX - 5, y: b.y + b.height - 10, width: 30, height: 20, buildingIndex: bi });
  }

  for (const road of roads) {
    const nc = randInt(2, 5);
    for (let i = 0; i < nc; i++) {
      const color = CAR_COLORS[randInt(0, CAR_COLORS.length)];
      if (road.direction === 'horizontal') {
        const lane = Math.random() > 0.5 ? 1 : -1;
        cars.push({
          x: rand(0, WORLD_WIDTH), y: road.y + (lane > 0 ? 15 : road.height - 35),
          width: 52, height: 26, speed: rand(100, 220),
          direction: 'horizontal', dirSign: lane, color, lane: lane > 0 ? 0 : 1,
        });
      } else {
        const lane = Math.random() > 0.5 ? 1 : -1;
        cars.push({
          x: road.x + (lane > 0 ? 15 : road.width - 39), y: rand(0, WORLD_HEIGHT),
          width: 26, height: 52, speed: rand(100, 220),
          direction: 'vertical', dirSign: lane, color, lane: lane > 0 ? 0 : 1,
        });
      }
    }
  }

  for (let i = 0; i < 60; i++) {
    puddles.push({ x: rand(100, WORLD_WIDTH - 100), y: rand(100, WORLD_HEIGHT - 100), radius: rand(8, 26) });
  }
  for (let i = 0; i < 45; i++) {
    trees.push({ x: rand(100, WORLD_WIDTH - 100), y: rand(100, WORLD_HEIGHT - 100) });
  }
  for (const road of roads) {
    if (road.direction === 'horizontal') {
      for (let lx = road.x + 100; lx < road.x + road.width; lx += randInt(180, 350)) {
        lamps.push({ x: lx, y: road.y - SW_W });
        lamps.push({ x: lx + 60, y: road.y + ROAD_W + SW_W - 10 });
      }
    }
  }

  return { width: WORLD_WIDTH, height: WORLD_HEIGHT, buildings, roads, restaurants, clientPoints, cars, sidewalks, puddles, trees, lamps };
}
