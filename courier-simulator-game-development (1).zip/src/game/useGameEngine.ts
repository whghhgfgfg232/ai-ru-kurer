import { useRef, useCallback, useEffect, useState } from 'react';
import { Player, GameWorld, Camera, Keys, Order, GameNotification, GameState } from './types';
import { WORLD_WIDTH, WORLD_HEIGHT, FOOD_NAMES, PHRASES, SHOP_ITEMS } from './constants';
import { generateWorld } from './worldGen';
import { renderGame } from './renderer';
import { initAudio, resumeAudio, playFootstep, playPickup, playDelivery, playFail, playHit, playCarPass } from './audio';

function findSafeSpawnPoint(world: GameWorld): { x: number; y: number } {
  // Try sidewalks first — pick one that doesn't overlap any building
  for (const sw of world.sidewalks) {
    const testX = sw.x + sw.width / 2;
    const testY = sw.y + sw.height / 2;
    if (testX < 150 || testY < 150) continue;
    if (testX > world.width - 150 || testY > world.height - 150) continue;
    const blocked = world.buildings.some(
      b => testX > b.x - 10 && testX < b.x + b.width + 10 &&
           testY > b.y - 10 && testY < b.y + b.height + 10
    );
    if (!blocked) return { x: testX, y: testY };
  }
  // Fallback: centre of a road
  if (world.roads.length > 0) {
    const r = world.roads[0];
    return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
  }
  return { x: 400, y: 400 };
}

function createPlayer(world: GameWorld): Player {
  const spawn = findSafeSpawnPoint(world);
  return {
    x: spawn.x,
    y: spawn.y,
    vx: 0,
    vy: 0,
    width: 16,
    height: 32,
    speed: 160,
    baseSpeed: 160,
    energy: 100,
    balance: 0,
    inventory: null,
    direction: 'down',
    isMoving: false,
    isSprinting: false,
    phrase: null,
    phraseTimer: 0,
    upgrades: { speedLevel: 0 },
    dead: false,
    deathReason: '',
    animFrame: 0,
    animTimer: 0,
  };
}

export function useGameEngine() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const worldRef = useRef<GameWorld>(generateWorld());
  const playerRef = useRef<Player>(createPlayer(worldRef.current));
  const cameraRef = useRef<Camera>({ x: 0, y: 0 });
  const keysRef = useRef<Keys>({});
  const timeRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  const orderIdRef = useRef<number>(0);
  const orderTimerRef = useRef<number>(0);
  const phraseTimerRef = useRef<number>(0);
  const animFrameRef = useRef<number>(0);
  const raincoatCountRef = useRef<number>(0);
  const currentOrderRef = useRef<Order | null>(null);
  const notifQueueRef = useRef<{ text: string; type: GameNotification['type'] }[]>([]);
  const deliveredCountRef = useRef<number>(0);

  const [gameState, setGameState] = useState<GameState>('menu');
  const [notifications, setNotifications] = useState<GameNotification[]>([]);
  const [currentOrderState, setCurrentOrderState] = useState<Order | null>(null);
  const [playerStats, setPlayerStats] = useState({
    balance: 0,
    energy: 100,
    hasInventory: false,
    orderTimer: 0,
    orderTimeLimit: 0,
  });
  const [deliveredCount, setDeliveredCount] = useState(0);

  const addNotification = useCallback((text: string, type: GameNotification['type']) => {
    const id = Date.now() + Math.random();
    setNotifications(prev => [...prev.slice(-4), { id, text, timer: 4, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  }, []);

  const flushNotifications = useCallback(() => {
    const queue = notifQueueRef.current;
    if (queue.length > 0) {
      for (const n of queue) {
        addNotification(n.text, n.type);
      }
      notifQueueRef.current = [];
    }
  }, [addNotification]);

  const generateOrder = useCallback((): Order | null => {
    const world = worldRef.current;
    if (world.restaurants.length === 0 || world.clientPoints.length === 0) return null;

    const restaurant = world.restaurants[Math.floor(Math.random() * world.restaurants.length)];
    const client = world.clientPoints[Math.floor(Math.random() * world.clientPoints.length)];
    const foodName = FOOD_NAMES[Math.floor(Math.random() * FOOD_NAMES.length)];
    const reward = 100 + Math.floor(Math.random() * 150);
    const timeLimit = 45 + Math.floor(Math.random() * 30);

    return {
      id: orderIdRef.current++,
      name: foodName,
      reward,
      penalty: Math.floor(reward * 0.3),
      restaurant,
      client,
      timeLimit,
      timer: 0,
      pickedUp: false,
      status: 'waiting',
    };
  }, []);

  const buyItem = useCallback((itemId: string) => {
    const player = playerRef.current;
    const item = SHOP_ITEMS.find(i => i.id === itemId);
    if (!item || !item.canBuy(player)) return false;

    player.balance -= item.price;
    item.action(player);

    if (itemId === 'raincoat') {
      raincoatCountRef.current++;
    }

    setPlayerStats({
      balance: player.balance,
      energy: Math.round(player.energy),
      hasInventory: !!player.inventory,
      orderTimer: 0,
      orderTimeLimit: 0,
    });

    addNotification(`Куплено: ${item.name}`, 'info');
    return true;
  }, [addNotification]);

  const resetGame = useCallback(() => {
    worldRef.current = generateWorld();
    playerRef.current = createPlayer(worldRef.current);
    cameraRef.current = { x: 0, y: 0 };
    orderTimerRef.current = 0;
    phraseTimerRef.current = 0;
    raincoatCountRef.current = 0;
    currentOrderRef.current = null;
    deliveredCountRef.current = 0;
    notifQueueRef.current = [];
    timeRef.current = 0;
    lastTimeRef.current = 0;
    setCurrentOrderState(null);
    setNotifications([]);
    setDeliveredCount(0);
    setPlayerStats({
      balance: 0,
      energy: 100,
      hasInventory: false,
      orderTimer: 0,
      orderTimeLimit: 0,
    });
  }, []);

  const startGame = useCallback(() => {
    resetGame();
    initAudio();
    resumeAudio();
    setGameState('playing');
    // Queue notification for after game loop starts
    setTimeout(() => {
      addNotification('Добро пожаловать на смену! Ожидайте заказ...', 'info');
    }, 100);
  }, [resetGame, addNotification]);

  // Input handling
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = true;
      if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(e.key.toLowerCase())) {
        e.preventDefault();
      }
      if (e.key === 'Escape') {
        setGameState(prev => prev === 'playing' ? 'paused' : prev === 'paused' ? 'playing' : prev);
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = false;
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Game loop
  useEffect(() => {
    if (gameState !== 'playing') return;

    let running = true;
    let uiUpdateAccum = 0;

    const gameLoop = (timestamp: number) => {
      if (!running) return;

      if (!lastTimeRef.current) lastTimeRef.current = timestamp;
      const rawDt = (timestamp - lastTimeRef.current) / 1000;
      const dt = Math.min(rawDt, 0.05);
      lastTimeRef.current = timestamp;
      timeRef.current += dt;
      uiUpdateAccum += dt;

      const player = playerRef.current;
      const world = worldRef.current;
      const keys = keysRef.current;
      const time = timeRef.current;

      if (player.dead) {
        setGameState('gameover');
        return;
      }

      // === INPUT ===
      let moveX = 0;
      let moveY = 0;
      if (keys['w'] || keys['arrowup']) { moveY = -1; player.direction = 'up'; }
      if (keys['s'] || keys['arrowdown']) { moveY = 1; player.direction = 'down'; }
      if (keys['a'] || keys['arrowleft']) { moveX = -1; player.direction = 'left'; }
      if (keys['d'] || keys['arrowright']) { moveX = 1; player.direction = 'right'; }

      const isSprinting = keys['shift'] && player.energy > 0;
      player.isSprinting = isSprinting;
      player.isMoving = moveX !== 0 || moveY !== 0;

      if (moveX !== 0 && moveY !== 0) {
        moveX *= 0.707;
        moveY *= 0.707;
      }

      let currentSpeed = player.baseSpeed;
      if (isSprinting) currentSpeed *= 1.6;
      if (player.energy <= 0) currentSpeed *= 0.4;
      player.speed = currentSpeed;

      const newX = player.x + moveX * currentSpeed * dt;
      const newY = player.y + moveY * currentSpeed * dt;

      let canMoveX = true;
      let canMoveY = true;
      const pHalfW = player.width / 2;
      const pHalfH = player.height / 2;

      for (const b of world.buildings) {
        if (
          newX + pHalfW > b.x && newX - pHalfW < b.x + b.width &&
          player.y + pHalfH > b.y && player.y - pHalfH < b.y + b.height
        ) {
          canMoveX = false;
        }
        if (
          player.x + pHalfW > b.x && player.x - pHalfW < b.x + b.width &&
          newY + pHalfH > b.y && newY - pHalfH < b.y + b.height
        ) {
          canMoveY = false;
        }
      }

      if (canMoveX) player.x = Math.max(pHalfW, Math.min(WORLD_WIDTH - pHalfW, newX));
      if (canMoveY) player.y = Math.max(pHalfH, Math.min(WORLD_HEIGHT - pHalfH, newY));

      // === ENERGY ===
      if (player.isMoving) {
        let drain = 3 * dt;
        if (isSprinting) drain = 10 * dt;
        drain *= Math.max(0.4, 1 - raincoatCountRef.current * 0.2);
        player.energy = Math.max(0, player.energy - drain);
        // Footstep sounds
        playFootstep(isSprinting, time);
      } else {
        player.energy = Math.min(100, player.energy + 0.5 * dt);
      }

      // === CAR MOVEMENT & COLLISION ===
      for (const car of world.cars) {
        if (car.direction === 'horizontal') {
          car.x += car.speed * car.dirSign * dt;
          if (car.x > WORLD_WIDTH + 100) car.x = -100;
          if (car.x < -100) car.x = WORLD_WIDTH + 100;
        } else {
          car.y += car.speed * car.dirSign * dt;
          if (car.y > WORLD_HEIGHT + 100) car.y = -100;
          if (car.y < -100) car.y = WORLD_HEIGHT + 100;
        }

        // Car proximity sound
        const carCX = car.x + car.width / 2;
        const carCY = car.y + car.height / 2;
        const carDist = Math.sqrt((player.x - carCX) ** 2 + (player.y - carCY) ** 2);
        if (carDist < 150) playCarPass(carDist);

        if (
          player.x + pHalfW > car.x &&
          player.x - pHalfW < car.x + car.width &&
          player.y + pHalfH > car.y &&
          player.y - pHalfH < car.y + car.height
        ) {
          player.dead = true;
          player.deathReason = 'Вас сбила машина! 🚗💀';
          playHit();
          setGameState('gameover');
          return;
        }
      }

      // === ORDER LOGIC (using ref) ===
      orderTimerRef.current += dt;
      const order = currentOrderRef.current;

      if (!order && orderTimerRef.current > 5) {
        const newOrder = generateOrder();
        if (newOrder) {
          currentOrderRef.current = newOrder;
          notifQueueRef.current.push({
            text: `📦 Новый заказ: ${newOrder.name} (+${newOrder.reward}₽)`,
            type: 'order',
          });
          orderTimerRef.current = 0;
        }
      }

      if (order && order.status !== 'delivered') {
        order.timer += dt;

        // Check pickup at restaurant
        if (!order.pickedUp) {
          const r = order.restaurant;
          const dist = Math.sqrt(
            Math.pow(player.x - (r.x + r.width / 2), 2) +
            Math.pow(player.y - (r.y + r.height / 2), 2)
          );
          if (dist < r.width / 2 + 30) {
            order.pickedUp = true;
            order.status = 'picked_up';
            player.inventory = order;
            playPickup();
            notifQueueRef.current.push({
              text: '📦 Заказ забран! Доставьте клиенту!',
              type: 'info',
            });
          }
        }

        // Check delivery at client
        if (order.pickedUp && order.status === 'picked_up') {
          const c = order.client;
          const dist = Math.sqrt(
            Math.pow(player.x - (c.x + c.width / 2), 2) +
            Math.pow(player.y - (c.y + c.height / 2), 2)
          );
          if (dist < 35) {
            if (order.timer <= order.timeLimit) {
              player.balance += order.reward;
              playDelivery();
              notifQueueRef.current.push({
                text: `✅ Доставлено! +${order.reward}₽`,
                type: 'success',
              });
            } else {
              const reduced = Math.max(0, order.reward - order.penalty);
              player.balance += reduced;
              playFail();
              notifQueueRef.current.push({
                text: `⚠️ Опоздание! +${reduced}₽ (штраф -${order.penalty}₽)`,
                type: 'fail',
              });
            }
            player.inventory = null;
            order.status = 'delivered';
            currentOrderRef.current = null;
            deliveredCountRef.current++;
            orderTimerRef.current = 0;
          }
        }

        // Order timeout
        if (order.timer > order.timeLimit * 2) {
          player.balance -= order.penalty;
          player.inventory = null;
          playFail();
          notifQueueRef.current.push({
            text: `❌ Заказ отменён! -${order.penalty}₽`,
            type: 'fail',
          });
          currentOrderRef.current = null;
          orderTimerRef.current = 0;
        }
      }

      // === RANDOM PHRASES ===
      phraseTimerRef.current += dt;
      if (phraseTimerRef.current > 8 + Math.random() * 12) {
        player.phrase = PHRASES[Math.floor(Math.random() * PHRASES.length)];
        player.phraseTimer = 3;
        phraseTimerRef.current = 0;
      }
      if (player.phraseTimer > 0) {
        player.phraseTimer -= dt;
        if (player.phraseTimer <= 0) {
          player.phrase = null;
        }
      }

      // === CAMERA ===
      const canvas = canvasRef.current;
      if (canvas) {
        const canvasW = canvas.width;
        const canvasH = canvas.height;
        const targetCamX = player.x - canvasW / 2;
        const targetCamY = player.y - canvasH / 2;
        const cam = cameraRef.current;
        cam.x += (targetCamX - cam.x) * 0.08;
        cam.y += (targetCamY - cam.y) * 0.08;
        cam.x = Math.max(0, Math.min(WORLD_WIDTH - canvasW, cam.x));
        cam.y = Math.max(0, Math.min(WORLD_HEIGHT - canvasH, cam.y));
      }

      // === UPDATE UI STATE (throttled) ===
      if (uiUpdateAccum > 0.05) {
        uiUpdateAccum = 0;
        const curOrd = currentOrderRef.current;
        setPlayerStats({
          balance: player.balance,
          energy: Math.round(player.energy),
          hasInventory: !!player.inventory,
          orderTimer: curOrd ? curOrd.timer : 0,
          orderTimeLimit: curOrd ? curOrd.timeLimit : 0,
        });
        setCurrentOrderState(curOrd ? { ...curOrd } : null);
        setDeliveredCount(deliveredCountRef.current);
        flushNotifications();
      }

      // === RENDER ===
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          renderGame(
            ctx,
            canvas.width,
            canvas.height,
            world,
            player,
            cameraRef.current,
            currentOrderRef.current,
            time
          );
        }
      }

      animFrameRef.current = requestAnimationFrame(gameLoop);
    };

    lastTimeRef.current = 0;
    animFrameRef.current = requestAnimationFrame(gameLoop);

    return () => {
      running = false;
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [gameState, generateOrder, flushNotifications]);

  // Handle canvas resize
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return {
    canvasRef,
    gameState,
    setGameState,
    playerStats,
    notifications,
    currentOrder: currentOrderState,
    deliveredCount,
    startGame,
    resetGame,
    buyItem,
    playerRef,
    deathReason: playerRef.current.deathReason,
  };
}
