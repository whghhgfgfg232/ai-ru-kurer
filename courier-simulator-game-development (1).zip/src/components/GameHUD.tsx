import React from 'react';
import { Zap, Package, Clock, Coins } from 'lucide-react';
import { Order, GameNotification } from '../game/types';

interface GameHUDProps {
  balance: number;
  energy: number;
  hasInventory: boolean;
  currentOrder: Order | null;
  notifications: GameNotification[];
  deliveredCount: number;
  onOpenShop: () => void;
  onPause: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  balance,
  energy,
  hasInventory,
  currentOrder,
  notifications,
  deliveredCount,
  onOpenShop,
  onPause,
}) => {
  const energyPct = Math.max(0, Math.min(100, energy));
  const energyHue = energy > 50 ? 120 : energy > 20 ? 40 : 0;
  const isLow = energy <= 20;

  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* ── TOP BAR ── */}
      <div className="absolute top-0 left-0 right-0 pointer-events-auto p-2.5 flex items-start gap-2">
        {/* Balance */}
        <div
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl"
          style={{
            background: 'rgba(10, 12, 20, 0.75)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255,255,255,0.06)',
            boxShadow: '0 2px 12px rgba(0,0,0,0.3)',
          }}
        >
          <Coins className="w-4 h-4 text-yellow-400" />
          <span className="text-yellow-400 font-bold text-base tabular-nums">{balance}₽</span>
        </div>

        {/* Energy bar */}
        <div
          className="flex-1 max-w-[220px] px-3.5 py-2 rounded-xl"
          style={{
            background: 'rgba(10, 12, 20, 0.75)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255,255,255,0.06)',
            boxShadow: '0 2px 12px rgba(0,0,0,0.3)',
          }}
        >
          <div className="flex items-center gap-1.5 mb-1">
            <Zap className={`w-3.5 h-3.5 ${isLow ? 'text-red-400 animate-pulse' : 'text-green-400'}`} />
            <span className="text-[10px] text-gray-500 uppercase tracking-wider">энергия</span>
            <span className={`ml-auto text-xs font-bold tabular-nums ${isLow ? 'text-red-400' : 'text-gray-300'}`}>
              {energy}%
            </span>
          </div>
          <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.08)' }}>
            <div
              className={`h-full rounded-full transition-all duration-200 ${isLow ? 'animate-pulse' : ''}`}
              style={{
                width: `${energyPct}%`,
                background: `hsl(${energyHue}, 70%, 50%)`,
                boxShadow: `0 0 8px hsla(${energyHue}, 70%, 50%, 0.4)`,
              }}
            />
          </div>
        </div>

        {/* Deliveries */}
        <div
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl"
          style={{
            background: 'rgba(10, 12, 20, 0.75)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255,255,255,0.06)',
            boxShadow: '0 2px 12px rgba(0,0,0,0.3)',
          }}
        >
          <Package className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-blue-400 text-sm font-bold tabular-nums">{deliveredCount}</span>
        </div>

        {/* Spacer */}
        <div className="flex-1" />

        {/* Shop */}
        <button
          onClick={onOpenShop}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl transition-all duration-200 hover:scale-105 active:scale-95"
          style={{
            background: 'linear-gradient(135deg, rgba(180, 130, 20, 0.6), rgba(160, 100, 10, 0.6))',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(240, 200, 40, 0.2)',
            boxShadow: '0 2px 12px rgba(0,0,0,0.3)',
          }}
        >
          <span className="text-sm">🛒</span>
          <span className="text-yellow-200 font-semibold text-xs hidden sm:inline">Магазин</span>
        </button>

        {/* Pause */}
        <button
          onClick={onPause}
          className="flex items-center justify-center w-9 h-9 rounded-xl transition-all duration-200 hover:scale-105 active:scale-95"
          style={{
            background: 'rgba(10, 12, 20, 0.75)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255,255,255,0.06)',
            boxShadow: '0 2px 12px rgba(0,0,0,0.3)',
          }}
        >
          <span className="text-gray-400 text-sm">⏸</span>
        </button>
      </div>

      {/* ── ORDER PANEL ── */}
      {currentOrder && (
        <div className="absolute bottom-16 left-3 right-3 pointer-events-auto">
          <div
            className="max-w-md mx-auto rounded-2xl p-3.5"
            style={{
              background: 'rgba(10, 12, 20, 0.82)',
              backdropFilter: 'blur(16px)',
              border: `1px solid ${hasInventory ? 'rgba(60, 179, 113, 0.2)' : 'rgba(232, 168, 62, 0.2)'}`,
              boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
            }}
          >
            {/* Order header */}
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-2">
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-sm"
                  style={{
                    background: hasInventory
                      ? 'rgba(60, 179, 113, 0.2)'
                      : 'rgba(232, 168, 62, 0.2)',
                  }}
                >
                  {hasInventory ? '📦' : '🍽'}
                </div>
                <div>
                  <div className="text-white font-semibold text-sm leading-tight">{currentOrder.name}</div>
                  <div className={`text-[10px] font-medium ${!currentOrder.pickedUp ? 'text-orange-400' : 'text-green-400'}`}>
                    {!currentOrder.pickedUp ? '→ Забрать из ресторана' : '→ Доставить клиенту'}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-yellow-400 font-bold text-sm">+{currentOrder.reward}₽</div>
                <div className="flex items-center gap-1 justify-end">
                  <Clock className="w-3 h-3 text-gray-500" />
                  <span className={`text-xs font-bold tabular-nums ${
                    currentOrder.timer > currentOrder.timeLimit ? 'text-red-400' :
                    currentOrder.timer > currentOrder.timeLimit * 0.7 ? 'text-yellow-400' :
                    'text-gray-400'
                  }`}>
                    {Math.max(0, Math.floor(currentOrder.timeLimit - currentOrder.timer))}с
                  </span>
                </div>
              </div>
            </div>

            {/* Timer bar */}
            <div className="w-full h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
              {(() => {
                const pct = Math.max(0, Math.min(100, (1 - currentOrder.timer / currentOrder.timeLimit) * 100));
                const hue = currentOrder.timer > currentOrder.timeLimit ? 0
                  : currentOrder.timer > currentOrder.timeLimit * 0.7 ? 40 : 120;
                return (
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${pct}%`,
                      background: `hsl(${hue}, 70%, 50%)`,
                      boxShadow: `0 0 6px hsla(${hue}, 70%, 50%, 0.4)`,
                    }}
                  />
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* ── CONTROLS HINT ── */}
      <div className="absolute bottom-2.5 left-2.5 pointer-events-none">
        <div
          className="px-2.5 py-1 rounded-lg"
          style={{ background: 'rgba(10,12,20,0.4)' }}
        >
          <span className="text-gray-600 text-[9px] tracking-wide">
            WASD · Shift=бег · Esc=пауза
          </span>
        </div>
      </div>

      {/* ── NOTIFICATIONS ── */}
      <div className="absolute top-16 right-2.5 flex flex-col gap-2 pointer-events-none max-w-xs">
        {notifications.map(n => {
          const styles: Record<string, { bg: string; border: string; text: string }> = {
            order: { bg: 'rgba(120, 70, 10, 0.85)', border: 'rgba(232, 168, 62, 0.3)', text: 'text-orange-200' },
            success: { bg: 'rgba(20, 80, 50, 0.85)', border: 'rgba(60, 179, 113, 0.3)', text: 'text-green-200' },
            fail: { bg: 'rgba(100, 20, 20, 0.85)', border: 'rgba(220, 60, 60, 0.3)', text: 'text-red-200' },
            info: { bg: 'rgba(20, 40, 80, 0.85)', border: 'rgba(60, 120, 220, 0.3)', text: 'text-blue-200' },
          };
          const s = styles[n.type] || styles.info;
          return (
            <div
              key={n.id}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium animate-slide-in ${s.text}`}
              style={{
                background: s.bg,
                backdropFilter: 'blur(8px)',
                border: `1px solid ${s.border}`,
                boxShadow: '0 2px 12px rgba(0,0,0,0.3)',
              }}
            >
              {n.text}
            </div>
          );
        })}
      </div>
    </div>
  );
};
