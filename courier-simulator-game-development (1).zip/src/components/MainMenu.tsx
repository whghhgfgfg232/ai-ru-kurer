import React from 'react';

interface MainMenuProps {
  onStart: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({ onStart }) => {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-50 overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, #0f1218 0%, #181c28 40%, #1a1e2c 70%, #12141c 100%)',
      }}
    >
      {/* Animated rain */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-40">
        {Array.from({ length: 60 }).map((_, i) => (
          <div
            key={i}
            className="absolute bg-gradient-to-b from-transparent via-blue-300/30 to-transparent animate-rain"
            style={{
              left: `${(i * 31 + 7) % 100}%`,
              width: '1px',
              height: `${40 + (i % 4) * 15}px`,
              animationDelay: `${(i * 0.08) % 2}s`,
              animationDuration: `${0.6 + (i % 5) * 0.15}s`,
            }}
          />
        ))}
      </div>

      {/* City skyline silhouette */}
      <div className="absolute bottom-0 left-0 right-0 flex items-end justify-center gap-[2px] px-2 opacity-[0.12]">
        {Array.from({ length: 30 }).map((_, i) => {
          const h = 60 + ((i * 41 + 17) % 180);
          const w = 22 + ((i * 13) % 30);
          return (
            <div key={i} className="relative" style={{ width: `${w}px`, height: `${h}px`, background: '#3a3e50' }}>
              <div className="grid grid-cols-2 gap-[2px] p-[3px] pt-[6px]">
                {Array.from({ length: Math.floor(h / 18) }).map((_, j) => (
                  <div
                    key={j}
                    className="h-[6px]"
                    style={{
                      background: (i + j) % 4 === 0
                        ? 'rgba(200, 168, 74, 0.5)'
                        : (i + j) % 5 === 0
                          ? 'rgba(100, 160, 220, 0.3)'
                          : 'rgba(30, 32, 50, 0.6)',
                    }}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Logo */}
      <div className="relative z-10 text-center mb-10">
        <div className="text-7xl mb-5 drop-shadow-lg" style={{ filter: 'drop-shadow(0 0 20px rgba(240, 208, 32, 0.3))' }}>
          🚴
        </div>
        <h1
          className="text-5xl sm:text-6xl font-black tracking-tighter leading-none mb-1"
          style={{
            background: 'linear-gradient(135deg, #f0d020 0%, #e8a020 50%, #f0c030 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            filter: 'drop-shadow(0 2px 8px rgba(240, 200, 32, 0.3))',
          }}
        >
          СИМУЛЯТОР
        </h1>
        <h2
          className="text-4xl sm:text-5xl font-black tracking-tighter leading-none mb-5"
          style={{
            background: 'linear-gradient(135deg, #e8a020 0%, #d09018 50%, #e8b830 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            filter: 'drop-shadow(0 2px 6px rgba(220, 160, 24, 0.25))',
          }}
        >
          КУРЬЕРА
        </h2>
        <p className="text-gray-500 text-sm font-light tracking-wide">
          Россия · Спальный район · Осень
        </p>
        <p className="text-gray-600 text-xs mt-1">
          Доставляй еду. Зарабатывай рубли. Выживай.
        </p>
      </div>

      {/* Start button */}
      <button
        onClick={onStart}
        className="relative z-10 group cursor-pointer mb-10"
      >
        <div
          className="px-14 py-4 rounded-2xl font-black text-xl text-gray-900 transition-all duration-300 group-hover:scale-105 group-active:scale-95"
          style={{
            background: 'linear-gradient(135deg, #f0d020 0%, #e8a818 100%)',
            boxShadow: '0 4px 24px rgba(240, 200, 32, 0.3), 0 2px 8px rgba(0,0,0,0.2)',
          }}
        >
          НАЧАТЬ СМЕНУ
        </div>
        <div
          className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
          style={{
            boxShadow: '0 8px 40px rgba(240, 200, 32, 0.5), 0 0 60px rgba(240, 200, 32, 0.15)',
          }}
        />
      </button>

      {/* Controls */}
      <div className="relative z-10 flex flex-wrap justify-center gap-x-6 gap-y-2 text-gray-600 text-[11px] max-w-md px-4">
        <span className="flex items-center gap-1.5">
          <kbd className="px-1.5 py-0.5 rounded bg-gray-800 text-gray-400 text-[10px] font-mono border border-gray-700">WASD</kbd>
          движение
        </span>
        <span className="flex items-center gap-1.5">
          <kbd className="px-1.5 py-0.5 rounded bg-gray-800 text-gray-400 text-[10px] font-mono border border-gray-700">Shift</kbd>
          бег
        </span>
        <span className="flex items-center gap-1.5">
          <kbd className="px-1.5 py-0.5 rounded bg-gray-800 text-gray-400 text-[10px] font-mono border border-gray-700">Esc</kbd>
          пауза
        </span>
      </div>

      <div className="absolute bottom-3 text-gray-800 text-[10px] tracking-widest uppercase">
        React + Canvas · v1.0
      </div>
    </div>
  );
};
