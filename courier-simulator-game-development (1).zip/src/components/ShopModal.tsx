import React from 'react';
import { X } from 'lucide-react';
import { SHOP_ITEMS } from '../game/constants';
import { Player } from '../game/types';

interface ShopModalProps {
  player: React.RefObject<Player | null>;
  balance: number;
  onBuy: (itemId: string) => boolean;
  onClose: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({ player, balance, onBuy, onClose }) => {
  const p = player.current;
  if (!p) return null;

  return (
    <div className="absolute inset-0 flex items-center justify-center z-50"
      style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(6px)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        className="max-w-md w-full mx-4 rounded-2xl p-5 animate-scale-in"
        style={{
          background: 'linear-gradient(180deg, rgba(18, 20, 30, 0.97), rgba(14, 16, 24, 0.97))',
          border: '1px solid rgba(255,255,255,0.06)',
          boxShadow: '0 8px 40px rgba(0,0,0,0.5)',
        }}
      >
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-bold text-white">🛒 Магазин</h2>
            <p className="text-yellow-500/70 text-xs mt-0.5">Баланс: <span className="font-bold text-yellow-400">{balance}₽</span></p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-500 hover:text-white hover:bg-white/5 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2">
          {SHOP_ITEMS.map(item => {
            const canBuy = item.canBuy(p);
            return (
              <div
                key={item.id}
                className={`flex items-center gap-3 p-3 rounded-xl transition-all duration-200 ${
                  canBuy ? 'hover:bg-white/[0.03]' : 'opacity-40'
                }`}
                style={{
                  background: 'rgba(255,255,255,0.02)',
                  border: `1px solid ${canBuy ? 'rgba(255,255,255,0.05)' : 'rgba(255,255,255,0.02)'}`,
                }}
              >
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0"
                  style={{ background: 'rgba(255,255,255,0.04)' }}
                >
                  {item.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-white font-semibold text-sm">{item.name}</div>
                  <div className="text-gray-500 text-[11px]">{item.description}</div>
                </div>
                <button
                  onClick={() => onBuy(item.id)}
                  disabled={!canBuy}
                  className={`px-3.5 py-1.5 rounded-lg font-bold text-xs transition-all duration-200 shrink-0 ${
                    canBuy
                      ? 'text-gray-900 cursor-pointer hover:scale-105 active:scale-95'
                      : 'text-gray-600 cursor-not-allowed'
                  }`}
                  style={{
                    background: canBuy
                      ? 'linear-gradient(135deg, #f0d020, #e0a818)'
                      : 'rgba(255,255,255,0.04)',
                    boxShadow: canBuy ? '0 2px 8px rgba(240,200,32,0.25)' : 'none',
                  }}
                >
                  {item.price}₽
                </button>
              </div>
            );
          })}
        </div>

        <div className="mt-4 text-center">
          <button
            onClick={onClose}
            className="text-gray-600 hover:text-gray-400 text-[11px] transition-colors"
          >
            Esc — закрыть
          </button>
        </div>
      </div>
    </div>
  );
};
