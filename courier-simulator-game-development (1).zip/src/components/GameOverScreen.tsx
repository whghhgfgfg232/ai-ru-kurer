import React from 'react';

interface GameOverProps {
  reason: string;
  balance: number;
  deliveredCount: number;
  onRestart: () => void;
  onMainMenu: () => void;
}

export const GameOverScreen: React.FC<GameOverProps> = ({
  reason,
  balance,
  deliveredCount,
  onRestart,
  onMainMenu,
}) => {
  const stars = deliveredCount >= 10 ? 5 : deliveredCount >= 7 ? 4 : deliveredCount >= 4 ? 3 : deliveredCount >= 2 ? 2 : 1;

  return (
    <div
      className="absolute inset-0 flex items-center justify-center z-50"
      style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(10px)' }}
    >
      <div
        className="max-w-sm w-full mx-4 rounded-2xl p-7 text-center animate-scale-in"
        style={{
          background: 'linear-gradient(180deg, rgba(24, 12, 12, 0.97), rgba(14, 14, 20, 0.97))',
          border: '1px solid rgba(220, 60, 60, 0.15)',
          boxShadow: '0 8px 40px rgba(0,0,0,0.5), 0 0 60px rgba(200,40,40,0.08)',
        }}
      >
        <div className="text-5xl mb-3">💀</div>
        <h2
          className="text-3xl font-black mb-1"
          style={{
            background: 'linear-gradient(135deg, #e04040, #c03030)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}
        >
          КОНЕЦ СМЕНЫ
        </h2>
        <p className="text-gray-500 text-xs mb-6">{reason}</p>

        <div
          className="rounded-xl p-4 mb-2 text-left space-y-3"
          style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.04)' }}
        >
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-500">💰 Заработано</span>
            <span className="text-yellow-400 font-bold text-lg">{balance}₽</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-500">📦 Доставок</span>
            <span className="text-blue-400 font-bold text-lg">{deliveredCount}</span>
          </div>
        </div>

        {/* Star rating */}
        <div className="py-3 mb-4">
          <div className="flex justify-center gap-1 text-2xl">
            {Array.from({ length: 5 }).map((_, i) => (
              <span
                key={i}
                className="transition-all duration-500"
                style={{
                  filter: i < stars ? 'none' : 'grayscale(1) opacity(0.2)',
                  animationDelay: `${i * 0.15}s`,
                }}
              >
                ⭐
              </span>
            ))}
          </div>
          <p className="text-gray-600 text-[10px] mt-1">
            {stars >= 5 ? 'Легенда доставки!' : stars >= 4 ? 'Отличная смена!' : stars >= 3 ? 'Неплохо!' : stars >= 2 ? 'Можно лучше' : 'Первый раз?'}
          </p>
        </div>

        <div className="space-y-2.5">
          <button
            onClick={onRestart}
            className="w-full py-3 rounded-xl font-bold text-gray-900 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
            style={{
              background: 'linear-gradient(135deg, #f0d020, #e0a818)',
              boxShadow: '0 4px 16px rgba(240,200,32,0.25)',
            }}
          >
            🔄 Новая смена
          </button>
          <button
            onClick={onMainMenu}
            className="w-full py-3 rounded-xl font-bold text-gray-300 transition-all duration-200 hover:bg-white/[0.06]"
            style={{
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(255,255,255,0.06)',
            }}
          >
            🏠 Главное меню
          </button>
        </div>
      </div>
    </div>
  );
};
