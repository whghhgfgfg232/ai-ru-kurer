import React from 'react';

interface PauseMenuProps {
  onResume: () => void;
  onMainMenu: () => void;
  balance: number;
  deliveredCount: number;
}

export const PauseMenu: React.FC<PauseMenuProps> = ({ onResume, onMainMenu, balance, deliveredCount }) => {
  return (
    <div
      className="absolute inset-0 flex items-center justify-center z-50"
      style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)' }}
    >
      <div
        className="max-w-sm w-full mx-4 rounded-2xl p-7 text-center animate-scale-in"
        style={{
          background: 'linear-gradient(180deg, rgba(18, 20, 30, 0.97), rgba(14, 16, 24, 0.97))',
          border: '1px solid rgba(255,255,255,0.06)',
          boxShadow: '0 8px 40px rgba(0,0,0,0.5)',
        }}
      >
        <div className="text-4xl mb-3">⏸</div>
        <h2 className="text-2xl font-bold text-white mb-1">Пауза</h2>
        <p className="text-gray-600 text-xs mb-6">Курьер переводит дух...</p>

        <div
          className="rounded-xl p-4 mb-6 text-left space-y-2.5"
          style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.04)' }}
        >
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">💰 Заработано</span>
            <span className="text-yellow-400 font-bold">{balance}₽</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">📦 Доставок</span>
            <span className="text-blue-400 font-bold">{deliveredCount}</span>
          </div>
        </div>

        <div className="space-y-2.5">
          <button
            onClick={onResume}
            className="w-full py-3 rounded-xl font-bold text-gray-900 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
            style={{
              background: 'linear-gradient(135deg, #f0d020, #e0a818)',
              boxShadow: '0 4px 16px rgba(240,200,32,0.25)',
            }}
          >
            ▶ Продолжить
          </button>
          <button
            onClick={onMainMenu}
            className="w-full py-3 rounded-xl font-bold text-gray-300 transition-all duration-200 hover:bg-white/[0.06]"
            style={{
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(255,255,255,0.06)',
            }}
          >
            🏠 Главное меню
          </button>
        </div>

        <p className="text-gray-700 text-[10px] mt-5">Esc — продолжить</p>
      </div>
    </div>
  );
};
