import { useCallback, useEffect } from 'react';
import { useGameEngine } from './game/useGameEngine';
import { GameHUD } from './components/GameHUD';
import { MainMenu } from './components/MainMenu';
import { PauseMenu } from './components/PauseMenu';
import { GameOverScreen } from './components/GameOverScreen';
import { ShopModal } from './components/ShopModal';

export default function App() {
  const {
    canvasRef,
    gameState,
    setGameState,
    playerStats,
    notifications,
    currentOrder,
    deliveredCount,
    startGame,
    buyItem,
    playerRef,
    deathReason,
  } = useGameEngine();

  const handleOpenShop = useCallback(() => {
    setGameState('shop');
  }, [setGameState]);

  const handleCloseShop = useCallback(() => {
    setGameState('playing');
  }, [setGameState]);

  const handlePause = useCallback(() => {
    setGameState('paused');
  }, [setGameState]);

  const handleResume = useCallback(() => {
    setGameState('playing');
  }, [setGameState]);

  const handleMainMenu = useCallback(() => {
    setGameState('menu');
  }, [setGameState]);

  const handleRestart = useCallback(() => {
    startGame();
  }, [startGame]);

  // Handle Escape in shop/pause
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (gameState === 'shop') {
          setGameState('playing');
        }
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [gameState, setGameState]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-gray-900 select-none">
      {/* Game Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ imageRendering: 'pixelated' }}
      />

      {/* UI Overlays */}
      {gameState === 'menu' && (
        <MainMenu onStart={startGame} />
      )}

      {gameState === 'playing' && (
        <GameHUD
          balance={playerStats.balance}
          energy={playerStats.energy}
          hasInventory={playerStats.hasInventory}
          currentOrder={currentOrder}
          notifications={notifications}
          deliveredCount={deliveredCount}
          onOpenShop={handleOpenShop}
          onPause={handlePause}
        />
      )}

      {gameState === 'shop' && (
        <ShopModal
          player={playerRef}
          balance={playerStats.balance}
          onBuy={buyItem}
          onClose={handleCloseShop}
        />
      )}

      {gameState === 'paused' && (
        <PauseMenu
          onResume={handleResume}
          onMainMenu={handleMainMenu}
          balance={playerStats.balance}
          deliveredCount={deliveredCount}
        />
      )}

      {gameState === 'gameover' && (
        <GameOverScreen
          reason={deathReason || 'Смена окончена'}
          balance={playerStats.balance}
          deliveredCount={deliveredCount}
          onRestart={handleRestart}
          onMainMenu={handleMainMenu}
        />
      )}
    </div>
  );
}
